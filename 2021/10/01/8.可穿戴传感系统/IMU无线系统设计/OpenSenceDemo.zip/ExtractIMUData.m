
%% Selecting Data
import org.opensim.modeling.*
[fileName, pathName, index] = uigetfile({'*.mat'});

%% Laod dSPACE Data
load([pathName, fileName]);
recData = [];eval(['recData = ' fileName(1:end-4) ';']);
time = recData.X.Data(1:5:end)';
allData = recData.Y;
varNum = size(allData,2);
imuData = zeros(length(time), 24);
imuQuaternion = zeros(length(time), 24);

%% 
% headindFlag = questdlg('Whether headind data  be used?','Data Contersion Setting','Yes','No','Yes');
% dataFreq = questdlg('Data acquisition frequency?', 'Data Contersion Setting', '200Hz','500Hz','1000Hz','500Hz');
emImuDataName = {'IMU1_AngleX','IMU1_AngleY','IMU1_AngleZ',...
                 'IMU2_AngleX','IMU2_AngleY','IMU2_AngleZ',...
                 'IMU3_AngleX','IMU3_AngleY','IMU3_AngleZ',...
                 'IMU4_AngleX','IMU4_AngleY','IMU4_AngleZ',...
                 'IMU5_AngleX','IMU5_AngleY','IMU5_AngleZ',...
                 'IMU6_AngleX','IMU6_AngleY','IMU6_AngleZ',...
                 'IMU7_AngleX','IMU7_AngleY','IMU7_AngleZ'};
emImuDataIndex = [7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,4,5,6];

%% Extracting IMU Data and Converting to Quaternion
for imuNameIndex = 1:length(emImuDataName)
    for varIndex = 1:varNum
        if strcmp(emImuDataName(imuNameIndex), allData(varIndex).Name)
            imuData(:,emImuDataIndex(imuNameIndex)) = allData(varIndex).Data(1:5:end)'/180*pi;
        end
    end
end
for imuIndex = 1:8
    imuQuaternion(:,4*imuIndex-3:4*imuIndex) = angle2quat(imuData(:,3*imuIndex-2),imuData(:,3*imuIndex-1),imuData(:,3*imuIndex),'XYZ');
end

imuQuaternion(:,1:4) = imuQuaternion(:,5:8);

%% Save Quaternion STO File
fp = fopen([fileName(1:end-4), '.sto'],'w+');
fprintf(fp,'%s\r\n%s\r\n%s\r\n%s\r\n%s\r\n','DataRate=500.000000','DataType=Quaternion','version=3','OpenSimVersion=4.1','endheader');
fprintf(fp,'%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\r\n','time','torso_imu','pelvis_imu','femur_r_imu','tibia_r_imu','calcn_r_imu','tibia_l_imu','femur_l_imu','calcn_l_imu');
fprintf(fp,'%f\t%f,%f,%f,%f\t%f,%f,%f,%f\t%f,%f,%f,%f\t%f,%f,%f,%f\t%f,%f,%f,%f\t%f,%f,%f,%f\t%f,%f,%f,%f\t%f,%f,%f,%f\r\n',[time,imuQuaternion]');
fclose(fp);

%% OpenSense Setting
modelFileName = 'Rajagopal_2015.osim';          % The path to an input model
orientationsFileName = [fileName(1:end-4), '.sto'];   % The path to orientation data for calibration 
sensor_to_opensim_rotations = Vec3(0,0,0);             % The rotation of IMU data to the OpenSim world frame 
baseIMUName = 'pelvis_imu';                     % The base IMU is the IMU on the base body of the model that dictates the heading (forward) direction of the model.
baseIMUHeading = 'z';                           % The Coordinate Axis of the base IMU that points in the heading direction. 
visulizeCalibration = false;                    % Boolean to Visualize the Output model

%% Instantiate an IMUPlacer object
imuPlacer = IMUPlacer();

% Set properties for the IMUPlacer
imuPlacer.set_model_file(modelFileName);
imuPlacer.set_orientation_file_for_calibration(orientationsFileName);
imuPlacer.set_sensor_to_opensim_rotations(sensor_to_opensim_rotations);
imuPlacer.set_base_imu_label(baseIMUName);
imuPlacer.set_base_heading_axis(baseIMUHeading);

% Run the IMUPlacer
imuPlacer.run(visulizeCalibration);

% Get the model with the calibrated IMU's
model = imuPlacer.getCalibratedModel();

%% Print the calibrated model to file.
model.print(strrep(modelFileName, '.osim', '_calibrated.osim'));

%% Set variables to use
modelFileName = 'Rajagopal_2015_calibrated.osim';                % The path to an input model
orientationsFileName = [fileName(1:end-4), '.sto'];   % The path to orientation data for calibration 
sensor_to_opensim_rotation = Vec3(0,0,0); % The rotation of IMU data to the OpenSim world frame 
visualizeTracking = false;  % Boolean to Visualize the tracking simulation
startTime = time(1);            % Start time (in seconds) of the tracking simulation. 
endTime = time(end);              % End time (in seconds) of the tracking simulation.
resultsDirectory = pathName(1:end-1);

%% Instantiate an InverseKinematicsTool
imuIK = IMUInverseKinematicsTool();

%% Set the model path to be used for tracking
imuIK.set_model_file(modelFileName);
imuIK.set_orientations_file(orientationsFileName);
imuIK.set_sensor_to_opensim_rotations(sensor_to_opensim_rotation)
% Set time range in seconds
imuIK.set_time_range(0, startTime); 
imuIK.set_time_range(1, endTime);   
% Set a directory for the results to be written to
imuIK.set_results_directory(resultsDirectory)
% Run IK
imuIK.run(visualizeTracking);